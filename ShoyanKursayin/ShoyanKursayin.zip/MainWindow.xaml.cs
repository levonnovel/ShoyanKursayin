﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Xml;

namespace ShoyanKursayin
{
	/// <summary>
	/// Interaction logic for MainWindow.xaml
	/// </summary>
	public partial class MainWindow : Window
	{
		Fill inst;

		public MainWindow()
		{

			InitializeComponent();
		}

		/*	private void TextBox1_KeyDown(object sender, System.Windows.Input.KeyEventArgs e)
			{

				if (e.Key == Key.Return)
				{
					if (textBox1.Text.ToLower() == "пока")
					{
						MainWindow context = this;
						inst.Close();

						textBox2.Text = "Прощай";
					}
					else if (textBox1.Text.Length > 0)
					{
						textBox2.Text = inst.GetAnswer(textBox1.Text);

						XmlDocument doc = new XmlDocument();
						doc.Load("logsHistory.xml");
						XmlElement rep = doc.CreateElement("Replica");
						XmlElement quest = doc.CreateElement("Question");
						XmlElement answ = doc.CreateElement("Answer");
						quest.InnerText = textBox1.Text;
						answ.InnerText = textBox2.Text;
						rep.AppendChild(quest);
						rep.AppendChild(answ);
						XmlNodeList convs = doc.GetElementsByTagName("Conversation");
						XmlNode last = convs.Item(convs.Count - 1);
						last.AppendChild(rep);
						doc.Save("logsHistory.xml");

						textBlock1.Text = textBlock1.Text.Insert(0, textBox2.Text);
						textBlock1.Text = textBlock1.Text.Insert(0, new string(' ', 10));
						textBlock1.Text = textBlock1.Text.Insert(0, "\n");
						textBlock1.Text = textBlock1.Text.Insert(0, textBox1.Text);
						textBlock1.Text = textBlock1.Text.Insert(0, "\n");
						textBox1.Text = String.Empty;
					}

				}
				else if(e.Key == Key.Up)
				{
					textBox1.Text = "sss";
				}
			}*/

		private void Window_Loaded(object sender, RoutedEventArgs e)
		{
			inst = new Fill(this);
			textBox1.Focus();
			XmlDocument doc = new XmlDocument();
			doc.Load("logsHistory.xml");
			XmlElement conv = doc.CreateElement("Conversation");
			conv.SetAttribute("date", DateTime.Now.ToLongDateString());
			conv.SetAttribute("time", DateTime.Now.ToLongTimeString());
			XmlNode root = doc.ChildNodes.Item(1);
			root.AppendChild(conv);
			doc.Save("logsHistory.xml");
		}

		private void TextBox1_PrevKeyDown(object sender, KeyEventArgs e)
		{
			
			if (e.Key == Key.Return)
			{
				
				if (textBox1.Text.ToLower() == "пока" || textBox1.Text.ToLower() == "прощай")
				{
					MainWindow context = this;
					inst.Close();

					textBox2.Text = "Прощай";
				}
				else if (textBox1.Text.Length > 0)
				{
					inst.AllPrevQuestionList.Add(textBox1.Text);
					inst.pos = inst.AllPrevQuestionList.Count;
					textBox2.Text = inst.GetAnswer(textBox1.Text);

					XmlDocument doc = new XmlDocument();
					doc.Load("logsHistory.xml");
					XmlElement rep = doc.CreateElement("Replica");
					XmlElement quest = doc.CreateElement("Question");
					XmlElement answ = doc.CreateElement("Answer");
					quest.InnerText = textBox1.Text;
					answ.InnerText = textBox2.Text;
					rep.AppendChild(quest);
					rep.AppendChild(answ);
					XmlNodeList convs = doc.GetElementsByTagName("Conversation");
					XmlNode last = convs.Item(convs.Count - 1);
					last.AppendChild(rep);
					doc.Save("logsHistory.xml");

					textBlock1.Text = textBlock1.Text.Insert(0, textBox2.Text);
					textBlock1.Text = textBlock1.Text.Insert(0, new string(' ', 10));
					textBlock1.Text = textBlock1.Text.Insert(0, "\n");
					textBlock1.Text = textBlock1.Text.Insert(0, textBox1.Text);
					textBlock1.Text = textBlock1.Text.Insert(0, "\n");
					textBox1.Text = String.Empty;
				}

			}
			else if (e.Key == Key.Up)
			{
				if (inst.pos > 0)
				{
					inst.pos--;
					textBox1.Text = inst.AllPrevQuestionList[inst.pos];
				}

			}
			else if (e.Key == Key.Down)
			{
				if (inst.pos < inst.AllPrevQuestionList.Count - 1)
				{
					inst.pos++;
					textBox1.Text = inst.AllPrevQuestionList[inst.pos];
				}
				else
				{
					inst.pos = inst.AllPrevQuestionList.Count;
					textBox1.Text =String.Empty;
				}
			}
		}

	}
}